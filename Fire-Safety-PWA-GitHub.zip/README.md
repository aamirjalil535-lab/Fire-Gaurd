# Fire Safety Management System - install on mobile (Chrome) via GitHub Pages

1. Create a new GitHub repository (e.g. `fire-safety-app`), public or private with Pages enabled.
2. Upload ALL files in this `pwa` folder to the repository root:
   index.html, manifest.json, sw.js, icons/icon-192.png, icons/icon-512.png
3. In the repo: Settings > Pages > Build and deployment > Source: "Deploy from a branch",
   Branch: `main`, Folder: `/ (root)` > Save.
4. After 1-2 minutes the site is live at:  https://<your-username>.github.io/fire-safety-app/
5. On your Android phone open that link in Chrome.
   Tap the menu (three dots) > "Install app" (or "Add to Home screen").
   The app opens full-screen with its own icon, like a normal app.

Notes
- Data (records, receipts, members) is stored in the browser of each device. Use
  Settings > Backup regularly, and do not clear Chrome's site data.
- Every update: replace the files on GitHub; the app updates itself next time it opens.
- The app needs internet only for the first load and for the QR/Font libraries.
